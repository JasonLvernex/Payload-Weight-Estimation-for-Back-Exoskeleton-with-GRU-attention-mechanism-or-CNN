"""Time-series prediction main function

Author: Jason Tian Lyu
Contact: Tian_lyu16@u.nus.edu
------------------------------------
(1) Evaluate the models(CNN, GRU)

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import warnings
warnings.filterwarnings("ignore")

import matplotlib.pyplot as plt
import numpy as np
import os

from Data_Loader_GRU import CustomDataLoader
from Data_Loader_MFCC import MFCCDataLoader
from sklearn.metrics import confusion_matrix, f1_score, precision_score, accuracy_score,recall_score


import tensorflow as tf

# Assuming you have a file name for the sample you want to predict on
file_name_to_predict = 'C:\\Users\\Lenovo\\Desktop\\NUS_master\\data_sampled\\promgram_test\\serial_data_Tian_Lyu_15_2023-10-04-21-39-26.csv'  # Replace with your file name

# Create an instance of the CustomDataLoader class
data_loader = CustomDataLoader(data_dir='your_data_directory')

# Load the specific file for prediction
file_path = os.path.join(data_loader.data_dir, file_name_to_predict)
features, label = data_loader.load_csv_file(file_path)

# Convert features to a numpy array
features_np = np.array(list(features.as_numpy_iterator()))


# Load the saved model
basic_attention = tf.keras.models.load_model('./saved models manually/best_attention_model_12-03-01.h5')

num_samples = features_np.size // (32 * 14)  # Assuming each sample is of shape (32, 14)

# Reshape based on the inferred number of samples
features_np = features_np.reshape(num_samples, 32, 14)

test_y_hat = basic_attention.predict(features_np)

# Assuming test_y_hat contains the output probabilities
predicted_class = np.argmax(test_y_hat)

print(predicted_class)