"""MFCC+CNN method for time-series classification.

Author: Jason Lyu Tian
"""

# Necessary packages
import tensorflow as tf
import numpy as np
import os
import shutil
from tensorflow import keras
from tensorflow.keras import layers, models
from tensorflow.keras.layers import Dropout
from tensorflow.keras.utils import plot_model
from tensorflow.keras.callbacks import ModelCheckpoint, LambdaCallback
from sklearn.metrics import accuracy_score
from keras.metrics import categorical_accuracy
from Data_Loader_GRU import CustomDataLoader

#tf.compat.v1.disable_eager_execution()

class CNN():
    def __init__(self, model_parameters):
        self.task = model_parameters['task']
        self.n_layer = model_parameters['n_layer']
        self.Droupout_tf = model_parameters['Droupout_tf']
        self.batch_size = model_parameters['batch_size']
        self.epoch = model_parameters['epoch']
        self.learning_rate = model_parameters['learning_rate']
        self.save_file_directory = 'tmp\\CNN\\'

    def fit(self, x, y, val_x, val_y):
        x_dim = 12  # Number of MFCC features
        n_Channel = 14  # Number of channels


        num_classes = 4  # Number of output classes


        # Reshape the input data to fit the 1D CNN (assuming each sample is 14x12)
        print(x.shape)



        # Create a 1D CNN model

        ################ First Version ###############
        # model = models.Sequential([
        #     layers.Conv1D(filters=14, kernel_size=3, activation='relu', input_shape=(seq_len, x_dim)),
        #     layers.MaxPooling1D(pool_size=2),
        #     layers.Flatten(),
        #     layers.Dense(128, activation='relu'),
        #     layers.Dense(num_classes, activation='softmax')
        # ])
        ################ First Version ###############

        ################ Second Version ###############
        model = models.Sequential()

        model.add(layers.Conv1D(filters=14, kernel_size=3, activation='relu', input_shape=(n_Channel, x_dim)))
        model.add(layers.MaxPooling1D(pool_size=2, padding='same'))

        for layer_num in range(self.n_layer - 1):  # corrected loop structure
            model.add(layers.Conv1D(filters=14, kernel_size=3, activation='relu'))
            model.add(layers.MaxPooling1D(pool_size=2, padding='same'))

        model.add(layers.Flatten())

        if self.Droupout_tf :
            model.add(layers.Dropout(0.5))

        model.add(layers.Dense(128, activation='relu'))
        model.add(layers.Dense(num_classes, activation='softmax'))
        ################ Second Version ###############


        model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
        model.summary()

        # Generate a visualization of the model
        plot_model(model, to_file='model.png', show_shapes=True, show_layer_names=True)

        # Callback to save the best model checkpoint based on validation loss
        checkpoint_callback = ModelCheckpoint(
            'best_CNN_model.h5',
            monitor='val_loss',
            save_best_only=True,
            mode='min',
            verbose=1
        )

        # Train the model
        history = model.fit(x, y, epochs=self.epoch, batch_size=self.batch_size, validation_data=(val_x, val_y),callbacks=checkpoint_callback)

        # Save the trained model
        model.save('best_CNN_model.h5')

        # Convert the model to TensorFlow Lite
        converter = tf.lite.TFLiteConverter.from_keras_model(model)
        tflite_model = converter.convert()
        tflite_model_path = os.path.join(self.save_file_directory, 'model.tflite')
        with open(tflite_model_path, 'wb') as f:
            f.write(tflite_model)

    def predict(self, test_x):
        # Load the saved model
        loaded_model = tf.keras.models.load_model('best_CNN_model.h5')

        # Make predictions using the loaded model
        test_y_hat = loaded_model.predict(test_x)

        return test_y_hat