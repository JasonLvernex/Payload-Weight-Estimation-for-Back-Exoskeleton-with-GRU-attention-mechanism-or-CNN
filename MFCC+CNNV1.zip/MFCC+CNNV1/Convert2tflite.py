import tensorflow as tf

# 加载Keras模型
model = tf.keras.models.load_model('./saved models manually/best_attention_model_12-03-01.h5')

# 转换为TFLite模型
converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()

# 将TFLite模型保存到文件
with open('converted_GRU_model.tflite', 'wb') as f:
    f.write(tflite_model)