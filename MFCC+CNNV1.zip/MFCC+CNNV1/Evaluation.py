"""Time-series prediction main function

Author: Jason Tian Lyu
Contact: Tian_lyu16@u.nus.edu
------------------------------------
(1) Evaluate the models(CNN, GRU)

"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import warnings
warnings.filterwarnings("ignore")

import matplotlib.pyplot as plt
import numpy as np

from Data_Loader_GRU import CustomDataLoader
from Data_Loader_MFCC import MFCCDataLoader
from sklearn.metrics import confusion_matrix, f1_score, precision_score, accuracy_score,recall_score


import tensorflow as tf

def model_performance(true_labels, predicted_labels, metric_name):
    if metric_name == 'confusion_matrix':
        return confusion_matrix(true_labels.argmax(axis=1), predicted_labels.argmax(axis=1))
    elif metric_name == 'f1_score':
        return f1_score(true_labels.argmax(axis=1), predicted_labels.argmax(axis=1), average='weighted')
    elif metric_name == 'precision':
        return precision_score(true_labels.argmax(axis=1), predicted_labels.argmax(axis=1), average='weighted')
    elif metric_name == 'accuracy':
        return accuracy_score(true_labels.argmax(axis=1), predicted_labels.argmax(axis=1))
    elif metric_name == 'recall':
        return recall_score(np.argmax(true_labels, axis=1), np.argmax(predicted_labels, axis=1), average='weighted')
    else:
        raise ValueError("Invalid metric name. Choose from: 'confusion_matrix', 'f1_score', 'precision', 'accuracy'")

def Evaluate_model(args):
    if args.model_type == 'attention':
        # # Load data

        args.data_location = "C:\\Users\\Lenovo\\Desktop\\NUS_master\\data_sampled\\promgram_test"

        data_dir = args.data_location

        # Initialize the data loader
        data_loader = CustomDataLoader(data_dir, test_size=0.1, val_size=0.1,
                                       random_seed=42)  # Adjust test_size, val_size, and random_seed as needed

        # Create the datasets
        train_x, train_y, test_x, test_y, val_x, val_y = data_loader.create_datasets()
        # Load the saved model
        basic_attention = tf.keras.models.load_model('./saved models manually/best_attention_model_12-03-01.h5')

        test_y_hat = basic_attention.predict(val_x)

        # Evaluation

        test_y_hat = test_y_hat.numpy() if isinstance(test_y_hat, tf.Tensor) else test_y_hat
        val_y = val_y.numpy() if isinstance(val_y, tf.Tensor) else val_y

        f1 = model_performance(val_y, test_y_hat, 'f1_score')
        precision = model_performance(val_y, test_y_hat, 'precision')
        accuracy = model_performance(val_y, test_y_hat, 'accuracy')
        recall = model_performance(val_y, test_y_hat, 'recall')


        print('F1 Score:', f1)
        print('Precision:', precision)
        print('Accuracy:', accuracy)
        print('recall:', recall)

        confusion = model_performance(val_y, test_y_hat, 'confusion_matrix')

        print('Confusion Matrix:\n', confusion)

        # Plot confusion matrix
        custom_labels = ['0', '5', '10', '15']  # Replace these with your actual label names
        plt.figure(figsize=(8, 6))
        plt.imshow(confusion, cmap=plt.cm.Blues)
        plt.title('Confusion Matrix')
        plt.colorbar()
        tick_marks = np.arange(len(confusion))
        plt.xticks(tick_marks, custom_labels)
        plt.yticks(tick_marks, custom_labels)
        plt.xlabel('Predicted Label (Kg)')
        plt.ylabel('True Label (Kg)')
        for i in range(len(confusion)):
            for j in range(len(confusion)):
                plt.text(j, i, str(confusion[i][j]), ha='center', va='center', color='black')
        plt.tight_layout()

        # Save confusion matrix plot
        plt.savefig('confusion_matrix_GRU.png')
        plt.show()


    elif args.model_type == 'CNN':
        # # Load data

        args.data_location = "C:\\Users\\Lenovo\\Desktop\\NUS_master\\data_sampled\\MFCC_test"
        data_dir = args.data_location

        # Initialize the data loader
        data_loader = MFCCDataLoader(data_dir, test_size=0.2, val_size=0.1,
                                     random_seed=42)  # Adjust test_size, val_size, and random_seed as needed

        # Create the datasets
        train_x, train_y, test_x, test_y, val_x, val_y = data_loader.create_datasets()
        # Load the saved model
        MFCC_CNN = tf.keras.models.load_model('./saved models manually/MFCC/best_CNN_model_12-03-01.h5')
        test_y_hat = MFCC_CNN.predict(val_x)

        # Evaluation

        test_y_hat = test_y_hat.numpy() if isinstance(test_y_hat, tf.Tensor) else test_y_hat
        val_y = val_y.numpy() if isinstance(val_y, tf.Tensor) else val_y

        f1 = model_performance(val_y, test_y_hat, 'f1_score')
        precision = model_performance(val_y, test_y_hat, 'precision')
        accuracy = model_performance(val_y, test_y_hat, 'accuracy')
        recall = model_performance(val_y, test_y_hat, 'recall')

        print('F1 Score:', f1)
        print('Precision:', precision)
        print('Accuracy:', accuracy)
        print('recall:', recall)

        confusion = model_performance(val_y, test_y_hat, 'confusion_matrix')

        print('Confusion Matrix:\n', confusion)

        # Plot confusion matrix
        custom_labels = ['0', '5', '10', '15']  # Replace these with your actual label names
        plt.figure(figsize=(8, 6))
        plt.imshow(confusion, cmap=plt.cm.Blues)
        plt.title('Confusion Matrix')
        plt.colorbar()
        tick_marks = np.arange(len(confusion))
        plt.xticks(tick_marks, custom_labels)
        plt.yticks(tick_marks, custom_labels)
        plt.xlabel('Predicted Label (Kg)')
        plt.ylabel('True Label (Kg)')
        for i in range(len(confusion)):
            for j in range(len(confusion)):
                plt.text(j, i, str(confusion[i][j]), ha='center', va='center', color='black')
        plt.tight_layout()

        # Save confusion matrix plot
        plt.savefig('confusion_matrix_CNN.png')
        plt.show()

if __name__ == '__main__':
    # Inputs for the main function
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data_location",
        help='location of the vsc file',
        default="C:\\Users\\Lenovo\\Desktop\\NUS_master\\data_sampled\\MFCC_test",
        # "C:\\Users\\Lenovo\\Desktop\\NUS_master\\data_sampled\\promgram_test",
        type=str
    )
    parser.add_argument(
        '--task',
        choices=['classification', 'regression'],
        default='classification',
        type=str)
    parser.add_argument(
        '--metric_name',
        choices=['mse', 'mae'],
        default='mae',
        type=str)
    parser.add_argument(
        '--model_type',
        choices=['attention', 'CNN'],
        default='CNN',
        type=str)
    # parser.add_argument(
    #     '--model_location',
    #     choices=['./saved models manually/best_attention_model_12-03-01\\.h5', ''],
    #     default='attention',
    #     type=str)
    args = parser.parse_args()

    # Call main function
    Evaluate_model(args)

