import os
import tensorflow as tf
import re
from sklearn.model_selection import train_test_split
import numpy as np

num_features = 14
num_classes = 4  # Define the number of classes for one-hot encoding

class CustomDataLoader:
    def __init__(self, data_dir, test_size=0.1, val_size=0.1, random_seed=None):
        self.data_dir = data_dir
        self.test_size = test_size
        self.val_size = val_size
        self.random_seed = random_seed

    def extract_label_from_filename(self, file_name):
        pattern = r'serial_data_(.*?)_(\d+)_(\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-\d{2})'

        match = re.search(pattern, file_name)

        if match:
            label = int(match.group(2))
            if label == 0:
                label=0
            elif label ==5:
                label =1
            elif label ==10:
                label =2
            elif label ==15:
                label =3
            return label
        else:
            raise ValueError("Unable to extract label from filename: {}".format(file_name))

    def load_csv_file(self, file_path):
        data = tf.data.experimental.CsvDataset(
            file_path,
            record_defaults=[tf.float32] * num_features,
            header=True,
        )
        features = data.map(lambda *x: tf.stack(x))
        label = self.extract_label_from_filename(os.path.basename(file_path))
        return features, label  # Return the label as an integer

    def custom_data_generator(self):
        file_list = os.listdir(self.data_dir)
        for file_name in file_list:
            file_path = os.path.join(self.data_dir, file_name)
            yield self.load_csv_file(file_path)

    # def create_datasets(self):
    #     file_list = os.listdir(self.data_dir)
    #     train_files, test_val_files = train_test_split(
    #         file_list, test_size=self.test_size + self.val_size, random_state=self.random_seed
    #     )
    #     test_files, val_files = train_test_split(
    #         test_val_files, test_size=self.val_size / (self.test_size + self.val_size), random_state=self.random_seed
    #     )
    def create_datasets(self):
        file_list = os.listdir(self.data_dir)
        total_samples = len(file_list)

        # Calculate the number of samples for each set (rounded to integers)
        num_train_samples = round(total_samples * (1 - self.test_size - self.val_size))
        num_test_samples = round(total_samples * self.test_size)
        num_val_samples = total_samples - num_train_samples - num_test_samples

        train_files, test_val_files = train_test_split(
            file_list, test_size=num_test_samples + num_val_samples, random_state=self.random_seed
        )
        test_files, val_files = train_test_split(
            test_val_files, test_size=num_val_samples, random_state=self.random_seed
        )

        # def dataset_from_files_np(files):
        #     x_values = []
        #     y_values = []
        #
        #     for file_name in files:
        #         file_path = os.path.join(self.data_dir, file_name)
        #         features, label = self.load_csv_file(file_path)
        #         features = np.array(list(features.as_numpy_iterator()))
        #         x_values.append(features)
        #         y_values.append(label)  # Append the integer label
        #
        #     x_values = np.array(x_values)
        #     y_values = np.array(y_values)
        #     return x_values, y_values
        def dataset_from_files_np(files):
            x_values = []
            y_values = []

            for file_name in files:
                try:
                    file_path = os.path.join(self.data_dir, file_name)
                    features, label = self.load_csv_file(file_path)
                    features = np.array(list(features.as_numpy_iterator()))
                    x_values.append(features)
                    y_values.append(label)  # Append the integer label
                except Exception as e:
                    print(f"Error loading data from file: {file_name}")
                    print(f"Error message: {str(e)}")

            x_values = np.array(x_values)
            y_values = np.array(y_values)
            return x_values, y_values

        train_x, train_y = dataset_from_files_np(train_files)
        test_x, test_y = dataset_from_files_np(test_files)
        val_x, val_y = dataset_from_files_np(val_files)

        # One-hot encode the labels
        train_y=tf.constant(train_y)
        test_y = tf.constant(test_y)
        val_y = tf.constant(val_y)
        train_y = tf.one_hot(train_y, num_classes)
        test_y = tf.one_hot(test_y, num_classes)
        val_y = tf.one_hot(val_y, num_classes)
        # # One-hot encode the labels using NumPy
        # train_y = np.eye(num_classes)[train_y]
        # test_y = np.eye(num_classes)[test_y]
        # val_y = np.eye(num_classes)[val_y]

        return train_x, train_y, test_x, test_y, val_x, val_y

# Example usage:
# data_loader = CustomDataLoader(data_dir='your_data_directory')
# train_x, train_y, test_x, test_y, val_x, val_y = data_loader.create_datasets()


