import tkinter as tk
import serial

def read_serial_and_update_label():
    if ser.in_waiting > 0:  # Check if there's data available in the receive buffer
        line = ser.readline().decode().strip()
        print(line)  # Print received data

        if line.startswith('Trunk Lifting Detected'):
            label.config(text="Lifting Detected", fg="white")  # Change text color to white
            label.place(relx=0.5, rely=0.5, anchor=tk.CENTER)  # Center label in the window
            root.update()  # Update the tkinter window

        if line.startswith('Weight:'):
            weight = line.split(' ')[1]
            print(weight)
            label.config(text=f"Weight: {weight}", fg="white")  # Change text color to white
            label.place(relx=0.5, rely=0.5, anchor=tk.CENTER)  # Center label in the window
            root.update()  # Update the tkinter window

    root.after(100, read_serial_and_update_label)  # Check for new data every 100 milliseconds


ser = serial.Serial(
    port='COM3',
    baudrate=115200,
    parity=serial.PARITY_ODD,
    stopbits=serial.STOPBITS_TWO,
    bytesize=serial.SEVENBITS
)

root = tk.Tk()
root.title("Weight Display")
root.configure(bg='black')  # Set background color to black

label = tk.Label(root, text="", font=("Arial", 180), bg='black', fg='white')  # Set label background and text color
label.pack(padx=20, pady=20)

if __name__ == '__main__':
    root.after(100, read_serial_and_update_label)
    root.mainloop()  # Start tkinter main loop
