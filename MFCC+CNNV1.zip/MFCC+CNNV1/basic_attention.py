"""Basic Attention core functions for time-series prediction.

Author: Jason Lyu Tian
"""

# Necessary packages
import tensorflow as tf
import numpy as np
import os
import shutil
from tensorflow import keras
from tensorflow.keras import layers, models
from tensorflow.keras.utils import plot_model
from tensorflow.keras.callbacks import ModelCheckpoint, LambdaCallback
from sklearn.metrics import accuracy_score
from keras.metrics import categorical_accuracy
from Data_Loader_GRU import CustomDataLoader

#tf.compat.v1.disable_eager_execution()


class Attention():
  """Attention class.

  Attributes:
    - model_parameters:
      - task: classificiation or regression
      - h_dim: hidden state dimensions
      - batch_size: the number of samples in each mini-batch
      - epoch: the number of iterations
      - learning_rate: learning rate of training
  """
  def __init__(self, model_parameters):

    tf.compat.v1.reset_default_graph()
    self.task = model_parameters['task']
    self.h_dim = model_parameters['h_dim']
    self.batch_size = model_parameters['batch_size']
    self.epoch = model_parameters['epoch']
    self.learning_rate = model_parameters['learning_rate']

    self.save_file_directory = 'tmp\\attention\\'


  def process_batch_input_for_RNN(self, batch_input):
    """Function to convert batch input data to use scan ops of tensorflow.

    Args:
      - batch_input: original batch input

    Returns:
      - x: batch_input for RNN
    """
    batch_input_ = tf.transpose(batch_input, perm=[2, 0, 1])
    x = tf.transpose(batch_input_)
    return x


  def sample_X(self, m, n):
    """Sample from the real data (Mini-batch index sampling).
    """
    return np.random.permutation(m)[:n]


  # def fit(self, x, y):
  #   """Train the model.
  #
  #   Args:
  #     - x: training feature
  #     - y: training label
  #   """
  #
  #   # Basic parameters
  #   no, seq_len, x_dim = x.shape
  #   y_dim = len(y[0, :])
  #
  #   # Weights for GRU
  #   Wr = tf.Variable(tf.zeros([x_dim, self.h_dim]))
  #   Ur = tf.Variable(tf.zeros([self.h_dim, self.h_dim]))
  #   br = tf.Variable(tf.zeros([self.h_dim]))
  #
  #   Wu = tf.Variable(tf.zeros([x_dim, self.h_dim]))
  #   Uu = tf.Variable(tf.zeros([self.h_dim, self.h_dim]))
  #   bu = tf.Variable(tf.zeros([self.h_dim]))
  #
  #   Wh = tf.Variable(tf.zeros([x_dim, self.h_dim]))
  #   Uh = tf.Variable(tf.zeros([self.h_dim, self.h_dim]))
  #   bh = tf.Variable(tf.zeros([self.h_dim]))
  #
  #   # Weights for attention mechanism
  #   Wa1 = tf.Variable(tf.random.truncated_normal([self.h_dim + x_dim,
  #                                                 self.h_dim],
  #                                                mean=0, stddev=.01))
  #   Wa2 = tf.Variable(tf.random.truncated_normal([self.h_dim, y_dim],
  #                                                mean=0, stddev=.01))
  #   ba1 = tf.Variable(tf.random.truncated_normal([self.h_dim],
  #                                                mean=0, stddev=.01))
  #   ba2 = tf.Variable(tf.random.truncated_normal([y_dim], mean=0, stddev=.01))
  #
  #   # Weights for output layers
  #   Wo = tf.Variable(tf.random.truncated_normal([self.h_dim, y_dim],
  #                                        mean=0, stddev=.01))
  #   bo = tf.Variable(tf.random.truncated_normal([y_dim], mean=0, stddev=.01))
  #
  #   # Target
  #   Y = tf.compat.v1.placeholder(tf.float32, [None,1])
  #   # Input vector with shape[batch, seq, embeddings]
  #   _inputs = tf.compat.v1.placeholder(tf.float32, shape=[None, None, x_dim],
  #                                      name='inputs')
  #
  #   # Processing inputs to work with scan function
  #   processed_input = self.process_batch_input_for_RNN(_inputs)
  #
  #   # Initial Hidden States
  #   initial_hidden = _inputs[:, 0, :]
  #   initial_hidden = tf.matmul(initial_hidden, tf.zeros([x_dim, self.h_dim]))
  #
  #
  #   def GRU(previous_hidden_state, x):
  #     """Function for Forward GRU cell.
  #
  #     Args:
  #       - previous_hidden_state
  #       - x: current input
  #
  #     Returns:
  #       - current_hidden_state
  #     """
  #     # R Gate
  #     r = tf.sigmoid(tf.matmul(x, Wr) + \
  #                    tf.matmul(previous_hidden_state, Ur) + br)
  #     # U Gate
  #     u = tf.sigmoid(tf.matmul(x, Wu) + \
  #                    tf.matmul(previous_hidden_state, Uu) + bu)
  #     # Final Memory cell
  #     c = tf.tanh(tf.matmul(x, Wh) + \
  #                 tf.matmul( tf.multiply(r, previous_hidden_state), Uh) + bh)
  #     # Current Hidden state
  #     current_hidden_state = tf.multiply( (1 - u), previous_hidden_state ) + \
  #                            tf.multiply( u, c )
  #     return current_hidden_state
  #
  #
  #   def get_states():
  #     """Function to get the hidden and memory cells after forward pass.
  #
  #     Returns:
  #       - all_hidden_states
  #     """
  #     # Getting all hidden state through time
  #     all_hidden_states = tf.scan(GRU, processed_input,
  #                                 initializer=initial_hidden, name='states')
  #     return all_hidden_states
  #
  #
  #   def get_attention(hidden_state):
  #     """Function to get attention with the last input.
  #
  #     Args:
  #       - hidden_states
  #
  #     Returns:
  #       - e_values
  #     """
  #     inputs = tf.concat((hidden_state, processed_input[-1]), axis = 1)
  #     hidden_values = tf.nn.tanh(tf.matmul(inputs, Wa1) + ba1)
  #     e_values = (tf.matmul(hidden_values, Wa2) + ba2)
  #     return e_values
  #
  #
  #   def get_outputs():
  #     """Function for getting output and attention coefficient.
  #
  #     Returns:
  #       - output: final outputs
  #       - a_values: attention values
  #     """
  #     all_hidden_states = get_states()
  #     all_attention = tf.map_fn(get_attention, all_hidden_states)
  #     a_values = tf.nn.softmax(all_attention, axis = 0)
  #     final_hidden_state = tf.einsum('ijk,ijl->jkl', a_values,
  #                                    all_hidden_states)
  #     output = tf.nn.sigmoid(tf.matmul(final_hidden_state[:,0,:], Wo) + bo,
  #                            name='outputs')
  #     return output, a_values
  #
  #   # Getting all outputs from rnn
  #   outputs, attention_values = get_outputs()
  #
  #   # reshape out for sequence_loss
  #   if self.task == 'classification':
  #     loss = tf.reduce_mean(Y * tf.log(outputs + 1e-8) + \
  #                           (1-Y) * tf.log(1-outputs + 1e-8))
  #   elif self.task == 'regression':
  #     loss = tf.sqrt(tf.reduce_mean(tf.square(outputs - Y)))
  #
  #   # Optimization
  #   optimizer = tf.compat.v1.train.AdamOptimizer(self.learning_rate)
  #   train = optimizer.minimize(loss)
  #
  #   # Sessions
  #   sess = tf.compat.v1.Session()
  #   sess.run(tf.compat.v1.global_variables_initializer())
  #
  #   # Training
  #   iteration_per_epoch = int(no/self.batch_size)
  #   iterations = int((self.epoch * no) / self.batch_size)
  #
  #   for i in range(iterations):
  #
  #     idx = self.sample_X(no, self.batch_size)
  #     Input = x[idx,:,:]
  #     _, step_loss = sess.run([train, loss],
  #                             feed_dict={Y: y[idx], _inputs: Input})
  #
  #     # Print intermediate results
  #     if i % iteration_per_epoch == iteration_per_epoch-1:
  #       print('Epoch: ' + str(int(i/iteration_per_epoch)) +
  #             ', Loss: ' + str(np.round(step_loss, 4)))
  #
  #   # Reset the directory for saving
  #   if not os.path.exists(self.save_file_directory):
  #     os.makedirs(self.save_file_directory)
  #   else:
  #     shutil.rmtree(self.save_file_directory)
  #
  #   # Save model
  #   inputs = {'inputs': _inputs}
  #   outputs = {'outputs': outputs}
  #   tf.compat.v1.saved_model.simple_save(sess, self.save_file_directory,
  #                                        inputs, outputs)
  #
  #   # # # Save TFlite model
  #   # # converter = tf.lite.TFLiteConverter.from_keras_model(sess)
  #   # #
  #   # # converter.optimizations = [tf.lite.Optimize.DEFAULT]
  #   # # tflite_model = converter.convert()
  #   # # Assuming 'session' is your trained Session object
  #   # frozen_graph_def = tf.compat.v1.graph_util.convert_variables_to_constants(
  #   #   sess,
  #   #   sess.graph_def,
  #   #   output_node_names=outputs #['output_node_name']  # Replace with your output node name
  #   # )
  #   #
  #   # converter = tf.lite.TFLiteConverter.from_frozen_graph(
  #   #   graph_def=frozen_graph_def,
  #   #   input_arrays=_inputs, #['input_node_name'],  # Replace with your input node name
  #   #   output_arrays=outputs #['output_node_name']  # Replace with your output node name
  #   # )
  #
  #   # tflite_model = converter.convert()
  #
  #   # Convert to TensorFlow Lite model
  #
  #   converter = tf.lite.TFLiteConverter.from_saved_model(self.save_file_directory)
  #   converter.target_spec.supported_ops = [
  #     tf.lite.OpsSet.TFLITE_BUILTINS, tf.lite.OpsSet.SELECT_TF_OPS
  #   ]
  #   converter._experimental_lower_tensor_list_ops = True
  #   tflite_model = converter.convert()
  #
  #   #Generate C file
  #
  #   from tensorflow.lite.python.util import convert_bytes_to_c_source
  #
  #   source_text, header_text = convert_bytes_to_c_source(tflite_model, "RNNattention")
  #
  #   with  open('RNNattention.h', 'w') as file:
  #     file.write(header_text)
  #
  #   with  open('RNNattention.cc', 'w') as file:
  #     file.write(source_text)
  #
  #   # Save the TensorFlow Lite model
  #   tflite_model_path = os.path.join(self.save_file_directory, 'model.tflite')
  #   with open(tflite_model_path, 'wb') as f:
  #     f.write(tflite_model)

  def fit(self, x, y,val_x, val_y):
  # ... (same as before, but using Keras layers and model)
    """Train the model.

    Args:
      - x: training feature
      - y: training label
    """

    # # Basic parameters
    # no, seq_len, x_dim = x.shape
    # y_dim = len(y[0, :])
    #
    # # Create a Keras model with GRU and Attention
    # inputs = keras.Input(shape=(seq_len, x_dim))
    # gru_layer = layers.GRU(self.h_dim, return_sequences=True)(inputs)
    # attention_input = layers.Concatenate(axis=-1)([gru_layer, inputs])
    # attention_hidden = layers.Dense(self.h_dim, activation='tanh')(attention_input)
    # attention_scores = layers.Dense(1)(attention_hidden)
    # attention_scores = layers.Flatten()(attention_scores)
    # attention_weights = layers.Activation('softmax')(attention_scores)
    # attention_weights = layers.RepeatVector(self.h_dim)(attention_weights)
    # attention_weights = layers.Permute([2, 1])(attention_weights)
    # weighted_sequence = layers.Multiply()([gru_layer, attention_weights])
    # final_output = layers.Dense(y_dim, activation='linear')(weighted_sequence)  # Change activation to 'linear'
    # model = models.Model(inputs=inputs, outputs=final_output)


    # # Basic parameters
    # no, seq_len, x_dim = x.shape

    x_dim=14

    seq_len =32

    y_dim = 1 # len(y[0, :])

  # Define the number of classes
    num_classes = 4 #len(np.unique(y))  # Replace 'y' with your training labels

    # Create a Keras model with GRU and Attention
    inputs = keras.Input(shape=(seq_len, x_dim))
    gru_layer = layers.GRU(self.h_dim, return_sequences=True)(inputs)
    attention_input = layers.Concatenate(axis=-1)([gru_layer, inputs])
    attention_hidden = layers.Dense(self.h_dim, activation='tanh')(attention_input)
    attention_scores = layers.Dense(1)(attention_hidden)
    attention_scores = layers.Flatten()(attention_scores)
    attention_weights = layers.Activation('softmax')(attention_scores)
    attention_weights = layers.RepeatVector(self.h_dim)(attention_weights)
    attention_weights = layers.Permute([2, 1])(attention_weights)
    weighted_sequence = layers.Multiply()([gru_layer, attention_weights])
    # Remove the return_sequences=True for final GRU layer
    final_gru_layer = layers.GRU(self.h_dim, return_sequences=False)(weighted_sequence)
    final_output = layers.Dense(num_classes, activation='softmax')(final_gru_layer)
    model = models.Model(inputs=inputs, outputs=final_output)
    # Compile the model
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['categorical_accuracy'])  # Use 'mean_squared_error' for regression

    model.summary()

    # Generate a visualization of the model
    plot_model(model, to_file='model.png', show_shapes=True, show_layer_names=True)

    # Callback to save the best model checkpoint based on validation loss
    checkpoint_callback = ModelCheckpoint(
      'best_attention_model.h5',
      monitor='val_loss',
      save_best_only=True,
      mode='min',
      verbose=1
    )

    # Callback to compute and log accuracy during training
    # def compute_accuracy(epoch, logs):
    #   # Assuming you have a validation dataset (val_x, val_y)
    #   val_loss = logs['val_loss']  # Retrieve validation loss from logs
    #   val_acc = logs['val_accuracy']  # Retrieve validation accuracy from logs
    #   print(f'Validation Loss: {val_loss:.4f}, Validation Accuracy: {val_acc:.4f}')

    # Callback to compute and log accuracy during training
    def compute_accuracy(epoch, logs):
      # Assuming you have a validation dataset (val_x, val_y)
      val_loss = logs['val_loss']  # Retrieve validation loss from logs
      val_y_pred = self.predict(val_x)  # Predict on validation data
      val_accuracy = accuracy_score(val_y, val_y_pred)  # Calculate accuracy
      print(f'Epoch {epoch + 1}/{self.epoch} - Validation Loss: {val_loss:.4f} - Validation Accuracy: {val_accuracy:.4f}')

    # # Train the model
  #   model.fit(x, y, epochs=self.epoch, batch_size=self.batch_size)
  # Train the model with callbacks
    history = model.fit(
      x, y,
      epochs=self.epoch,
      batch_size=self.batch_size,
      validation_data=(val_x, val_y),
      callbacks=checkpoint_callback
      # callbacks=[checkpoint_callback, LambdaCallback(on_epoch_end=compute_accuracy)]
    )


    # Save the model in .h5 format
    model.save('best_attention_model.h5')

    # # Convert Keras model to TensorFlow Lite format
    #
    # converter = tf.lite.TFLiteConverter.from_keras_model(model)
    # converter.target_spec.supported_ops = [
    #   tf.lite.OpsSet.TFLITE_BUILTINS, tf.lite.OpsSet.SELECT_TF_OPS
    # ]
    # converter._experimental_lower_tensor_list_ops = True

    # Convert to TensorFlow Lite model

    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    tflite_model = converter.convert()

    #Generate C file

    from tensorflow.lite.python.util import convert_bytes_to_c_source

    source_text, header_text = convert_bytes_to_c_source(tflite_model, "RNNattention")

    with  open('RNNattention.h', 'w') as file:
      file.write(header_text)

    with  open('RNNattention.cc', 'w') as file:
      file.write(source_text)

    # Save the TensorFlow Lite model
    tflite_model_path = os.path.join(self.save_file_directory, 'model.tflite')
    with open(tflite_model_path, 'wb') as f:
      f.write(tflite_model)

  # def predict(self, test_x):
  #   """Prediction with trained model.
  #
  #   Args:
  #     - test_x: testing features
  #
  #   Returns:
  #     - test_y_hat: predictions on testing set
  #   """
  #
  #   graph = tf.Graph()
  #   with graph.as_default():
  #     with tf.compat.v1.Session() as sess:
  #       tf.compat.v1.saved_model.loader.load(sess, [tf.saved_model.SERVING],
  #                                            self.save_file_directory)
  #       x = graph.get_tensor_by_name('inputs:0')
  #       outputs = graph.get_tensor_by_name('outputs:0')
  #
  #       test_y_hat = sess.run(outputs, feed_dict={x: test_x})
  #
  #   return test_y_hat
  def predict(self, test_x):
    """Prediction with trained model.

    Args:
      - test_x: testing features

    Returns:
      - test_y_hat: predictions on the testing set
    """

    # Define a function for prediction
    @tf.function
    def prediction_step(model, inputs):
      return model(inputs, training=False)

    # Load the saved model
    loaded_model = tf.keras.models.load_model('best_attention_model.h5')

    # Make predictions using the loaded model
    test_y_hat = prediction_step(loaded_model, test_x)

    return test_y_hat



    