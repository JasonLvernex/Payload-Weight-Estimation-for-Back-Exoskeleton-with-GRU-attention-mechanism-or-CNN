"""Time-series prediction main function

Author: Jason Tian Lyu
Contact: Tian_lyu16@u.nus.edu
------------------------------------
(1) Load data
(2) Train model (CNN, Attention)

"""

# Necessary packages
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import warnings
warnings.filterwarnings("ignore")

from basic_attention import Attention
from My_MFCC_CNN import CNN
from utils import performance

from Data_Loader_GRU import CustomDataLoader
from Data_Loader_MFCC import MFCCDataLoader

import tensorflow as tf


def main (args):  
  """Time-series prediction main function.
  
  Args:
    - train_rate: training data ratio
    - seq_len: sequence length
    - task: classification or regression
    - model_type: rnn, lstm, gru, or attention
    - h_dim: hidden state dimensions
    - n_layer: number of layers
    - batch_size: the number of samples in each mini-batch
    - epoch: the number of iterations
    - learning_rate: learning rates
    - metric_name: mse or mae
  """


  # Model traininig / testing
  model_parameters = {'task': args.task,
                      'model_type': args.model_type,
                      'h_dim': args.h_dim,
                      'n_layer': args.n_layer,
                      'Droupout_tf':args.Droupout_tf,
                      'batch_size': args.batch_size,
                      'epoch': args.epoch,
                      'learning_rate': args.learning_rate}
  
  # if args.model_type in ['rnn','lstm','gru']:
  #   general_rnn = GeneralRNN(model_parameters)
  #   general_rnn.fit(train_x, train_y)
  #   test_y_hat = general_rnn.predict(test_x)
  if args.model_type == 'attention':
    # # Load data
    # train_x, train_y, test_x, test_y = data_loader(args.train_rate,
    #                                                args.seq_len)

    args.data_location="C:\\Users\\Lenovo\\Desktop\\NUS_master\\data_sampled\\promgram_test"

    data_dir = args.data_location
    batch_size = args.batch_size
    # Initialize the data loader
    data_loader = CustomDataLoader(data_dir, test_size=0.1, val_size=0.1,
                                 random_seed=42)  # Adjust test_size, val_size, and random_seed as needed

    # Create the datasets
    train_x, train_y, test_x, test_y, val_x, val_y = data_loader.create_datasets()
    basic_attention = Attention(model_parameters)    
    basic_attention.fit(train_x, train_y,test_x,test_y)
    # converter = tf.lite.TFLiteConverter.from_keras_model(basic_attention)
    #
    # converter.optimizations = [tf.lite.Optimize.DEFAULT]
    # tflite_model = converter.convert()

    test_y_hat = basic_attention.predict(val_x)

    # Evaluation
    result = performance(val_y, test_y_hat, args.metric_name)
    print('Performance (' + args.metric_name + '): ' + str(result))


  elif args.model_type == 'CNN':
    # # Load data
    # train_x, train_y, test_x, test_y = data_loader(args.train_rate,
    #                                                args.seq_len)

    args.data_location = "C:\\Users\\Lenovo\\Desktop\\NUS_master\\data_sampled\\MFCC_test"
    data_dir = args.data_location
    batch_size = args.batch_size
    # Initialize the data loader
    data_loader = MFCCDataLoader(data_dir, test_size=0.1, val_size=0.1,
                                 random_seed=42)  # Adjust test_size, val_size, and random_seed as needed

    # Create the datasets
    train_x, train_y, test_x, test_y, val_x, val_y = data_loader.create_datasets()
    MFCC_CNN = CNN(model_parameters)
    MFCC_CNN.fit(train_x, train_y, test_x, test_y)
    test_y_hat = MFCC_CNN.predict(val_x)

    # Evaluation
    result = performance(val_y, test_y_hat, args.metric_name)
    print('Performance (' + args.metric_name + '): ' + str(result))


##
if __name__ == '__main__':
  
  # Inputs for the main function
  parser = argparse.ArgumentParser()
  parser.add_argument(
      "--data_location",
      help='location of the vsc file',
      default= "C:\\Users\\Lenovo\\Desktop\\NUS_master\\data_sampled\\MFCC_test",#"C:\\Users\\Lenovo\\Desktop\\NUS_master\\data_sampled\\promgram_test",
      type=str
  )
  parser.add_argument(
      '--train_rate',
      help='training data ratio',
      default=0.8,
      type=str)
  parser.add_argument(
      '--seq_len',
      help='sequence length',
      default=32,
      type=int)
  parser.add_argument(
      '--model_type',
      choices=['attention','CNN'],
      default='attention',
      type=str)
  parser.add_argument(
      '--h_dim',
      default=15,#10
      type=int)
  parser.add_argument(
      '--n_layer',
      default=1,#5,
      type=int)
  parser.add_argument(
      '--Droupout_tf',
      default=False,
      type=bool)
  parser.add_argument(
      '--batch_size',
      default=1, #32,
      type=int)
  parser.add_argument(
      '--epoch',
      default=240,
      type=int)
  parser.add_argument(
      '--learning_rate',
      default=0.0001,
      type=float)
  parser.add_argument(
      '--task',
      choices=['classification','regression'],
      default='classification',
      type=str)
  parser.add_argument(
      '--metric_name',
      choices=['mse','mae'],
      default='mae',
      type=str)
  
  args = parser.parse_args() 
  
  # Call main function  
  main(args)