
import matplotlib.pyplot as plt
import numpy as np

# Assuming you have your confusion matrix data stored in a variable named confusion_matrix_data
confusion_matrix_data = np.array([[10, 3, 0, 1],
                                  [0, 6, 1, 1],
                                  [0, 1, 7, 1],
                                  [0, 0, 1, 7]])

custom_labels = ['0', '5', '10', '15']  # Replace these with your actual label names
plt.figure(figsize=(8, 6))
plt.imshow(confusion_matrix_data, cmap=plt.cm.Blues)
plt.title('Confusion Matrix')
plt.colorbar()
tick_marks = np.arange(len(confusion_matrix_data))
plt.xticks(tick_marks, custom_labels)
plt.yticks(tick_marks, custom_labels)
plt.xlabel('Predicted Label (Kg)')
plt.ylabel('True Label (Kg)')

for i in range(len(confusion_matrix_data)):
    for j in range(len(confusion_matrix_data)):
        plt.text(j, i, str(confusion_matrix_data[i][j]), ha='center', va='center', color='black')

plt.tight_layout()

# Save confusion matrix plot
plt.savefig('confusion_matrix_CNN_subject2.png')
plt.show()