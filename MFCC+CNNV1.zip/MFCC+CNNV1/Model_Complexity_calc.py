from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import warnings
warnings.filterwarnings("ignore")

import tensorflow as tf

import matplotlib.pyplot as plt
import numpy as np

from Data_Loader_GRU import CustomDataLoader
from Data_Loader_MFCC import MFCCDataLoader
from sklearn.metrics import confusion_matrix, f1_score, precision_score, accuracy_score,recall_score

# Load the saved model
basic_attention = tf.keras.models.load_model('./saved models manually/best_attention_model_12-03-01.h5')
# Calculate the number of parameters in the model
num_parameters = basic_attention.count_params()

print(f"Number of parameters in the modelGRU: {num_parameters}")

# Load the saved model
basic_attention = tf.keras.models.load_model('./saved models manually/MFCC/best_CNN_model_12-03-01.h5')
# Calculate the number of parameters in the model
num_parameters = basic_attention.count_params()

print(f"Number of parameters in the modelCNN: {num_parameters}")
